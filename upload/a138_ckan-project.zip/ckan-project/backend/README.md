# datasets-with-ckan-demo-backend
REST API for datasets-with-ckan-demo-frontend
